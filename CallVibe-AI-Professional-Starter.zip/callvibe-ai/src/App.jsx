import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Sparkles, Video, Phone, PhoneOff, Mic, MicOff, MessageCircle,
  Clock3, Crown, UserRound, Search, Settings, ShieldCheck, ArrowUpRight,
  Heart, WandSparkles, X, Send, LogIn, LogOut, Camera, Volume2, CircleHelp
} from "lucide-react";
import { supabase } from "./supabase";

const characters = [
  { id: "maya", name: "Maya", role: "The warm-hearted friend", vibe: "Kind • Cheerful • Curious", emoji: "🌸", gradient: "pink", online: true, description: "A positive, thoughtful character who loves a good conversation." },
  { id: "leo", name: "Leo", role: "The adventurous one", vibe: "Funny • Bold • Energetic", emoji: "🌊", gradient: "blue", online: true, description: "An upbeat fictional character ready to talk about music, travel, and big ideas." },
  { id: "aria", name: "Aria", role: "The creative dreamer", vibe: "Creative • Calm • Playful", emoji: "🦋", gradient: "purple", online: true, description: "A creative companion for ideas, stories, and relaxed chats." },
  { id: "noah", name: "Noah", role: "The thoughtful listener", vibe: "Patient • Smart • Supportive", emoji: "🌿", gradient: "green", online: false, description: "A calm fictional character who enjoys listening and exploring new topics." },
];

function getGreeting(name) {
  const h = new Date().getHours();
  const period = h < 12 ? "morning" : h < 17 ? "afternoon" : "evening";
  return `Good ${period}${name ? `, ${name}` : ""} ✨`;
}

export default function App() {
  const [selected, setSelected] = useState(characters[0]);
  const [callOpen, setCallOpen] = useState(false);
  const [callMode, setCallMode] = useState("demo");
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const [chatOpen, setChatOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const timerRef = useRef(null);

  const visibleCharacters = useMemo(() =>
    characters.filter(c => `${c.name} ${c.role} ${c.vibe}`.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (callOpen) {
      timerRef.current = setInterval(() => setElapsed(s => s + 1), 1000);
    } else {
      clearInterval(timerRef.current);
      setElapsed(0);
    }
    return () => clearInterval(timerRef.current);
  }, [callOpen]);

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  async function signIn(e) {
    e.preventDefault();
    if (!supabase) {
      setNotice("Connect Supabase in your environment settings to enable real accounts. Demo mode is available now.");
      return;
    }
    setBusy(true);
    try {
      const result = authMode === "signup"
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      setNotice(authMode === "signup" ? "Account request submitted. Check your email if confirmation is enabled." : "You're signed in.");
      setAuthOpen(false);
    } catch (err) { setNotice(err.message || "Could not sign in."); }
    finally { setBusy(false); }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setUser(null);
    setNotice("You have signed out.");
  }

  async function startCall() {
    setMessages([{ from: "ai", text: `Hi! I'm ${selected.name}, your fictional AI character. This is the visual demo call. Connect an avatar provider and AI API to enable live AI video and conversation.` }]);
    setCallMode("demo");
    setCallOpen(true);
    setChatOpen(true);
    try {
      const res = await fetch("/api/avatar/session", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ characterId: selected.id }) });
      if (res.ok) {
        const data = await res.json();
        if (data?.embedUrl) {
          setCallMode("live");
          setNotice("Avatar session connected. Follow your avatar provider's usage and consent requirements.");
        }
      }
    } catch { /* Local demo mode: API server may not be running. */ }
  }

  async function sendMessage(e) {
    e?.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    setMessages(prev => [...prev, { from: "you", text }]);
    try {
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: selected.id, message: text, history: messages.slice(-8) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "AI service is not configured.");
      setMessages(prev => [...prev, { from: "ai", text: data.reply }]);
      if (data.audioUrl && "speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(data.reply);
        window.speechSynthesis.speak(utterance);
      }
    } catch {
      const replies = [
        `That's interesting. Tell me a little more about what you mean.`,
        `I'm listening. What part of that matters most to you?`,
        `I like hearing your perspective. What happened next?`,
        `Thanks for sharing that with me. What would you like to talk about next?`
      ];
      setMessages(prev => [...prev, { from: "ai", text: replies[Math.floor(Math.random() * replies.length)] + " (Demo reply — connect an AI API for real AI responses.)" }]);
    }
  }

  function closeCall() {
    setCallOpen(false);
    setChatOpen(false);
    setNotice("Call ended. Demo calls do not connect to a real person.");
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="CallVibe AI home">
          <span className="brand-mark"><Video size={21} /></span>
          <span>CallVibe <b>AI</b></span>
        </a>
        <nav className="desktop-nav">
          <a className="active" href="#discover">Discover</a>
          <a href="#how">How it works</a>
          <a href="#plans">Plans</a>
        </nav>
        <div className="top-actions">
          <button className="icon-button" aria-label="Settings" onClick={() => setNotice("Settings will be available after account setup.")}><Settings size={18} /></button>
          {user ? <button className="button button-light" onClick={signOut}><LogOut size={16}/> Sign out</button> : <button className="button button-dark" onClick={() => { setAuthMode("signin"); setAuthOpen(true); }}><UserRound size={16}/> Sign in</button>}
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="live-dot" /> YOUR NEXT CONVERSATION STARTS HERE</div>
            <h1>Meet someone<br /><span>out of this world.</span></h1>
            <p>Discover fictional AI characters with unique personalities. Start a conversation, share a laugh, and make a little connection — on your terms.</p>
            <div className="hero-buttons">
              <a className="button button-primary" href="#discover">Explore characters <ArrowUpRight size={18}/></a>
              <button className="button button-outline" onClick={() => { setSelected(characters[0]); startCall(); }}><Video size={17}/> Try a demo call</button>
            </div>
            <div className="trust-row"><span><ShieldCheck size={16}/> Privacy-minded</span><span><Sparkles size={16}/> AI-generated characters</span></div>
          </div>
          <div className="hero-art">
            <div className="orb orb-one"></div><div className="orb orb-two"></div>
            <div className="hero-card card-back"><div className="mini-avatar blue">🌊</div><div><b>Leo</b><small>Adventure buddy</small></div><span className="online-pill">● Online</span></div>
            <div className="portrait-frame">
              <div className="portrait-glow"></div>
              <div className="portrait-face">🌸</div>
              <div className="portrait-label"><span className="mini-status"></span><div><b>Maya</b><small>Fictional AI character</small></div><span className="sound-bars"><i></i><i></i><i></i><i></i></span></div>
            </div>
            <div className="hero-card card-front"><span className="heart-icon"><Heart size={17} fill="currentColor"/></span><div><b>A little more connection</b><small>One conversation at a time</small></div></div>
            <div className="sparkle sparkle-a">✦</div><div className="sparkle sparkle-b">✧</div>
          </div>
        </section>

        <section className="stats-strip">
          <div><span className="stat-icon purple"><MessageCircle size={18}/></span><p><b>Talk naturally</b><small>Chat at your own pace</small></p></div>
          <div><span className="stat-icon orange"><WandSparkles size={18}/></span><p><b>Unique personalities</b><small>Find your conversation vibe</small></p></div>
          <div><span className="stat-icon green"><ShieldCheck size={18}/></span><p><b>Clear and transparent</b><small>Know when you're talking to AI</small></p></div>
        </section>

        <section className="discover section" id="discover">
          <div className="section-heading">
            <div><div className="eyebrow">YOUR NEW FAVORITES</div><h2>Find your <span>vibe.</span></h2><p>Every character has a story. Pick one and say hello.</p></div>
            <label className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search characters" /></label>
          </div>
          <div className="character-grid">
            {visibleCharacters.map((c, index) => <article className={`character-card ${c.gradient}`} key={c.id}>
              <div className={`character-art ${c.gradient}`}><span className="art-spark">✦</span><span className="character-emoji">{c.emoji}</span><span className={`availability ${c.online ? "is-online" : ""}`}>{c.online ? "Available" : "Coming soon"}</span></div>
              <div className="character-info"><div className="name-line"><div><h3>{c.name}</h3><p>{c.role}</p></div><button className="favorite" aria-label={`Favorite ${c.name}`} onClick={() => setNotice(`${c.name} added to your demo favorites.`)}><Heart size={18}/></button></div>
                <div className="vibe-tags">{c.vibe.split(" • ").map(tag => <span key={tag}>{tag}</span>)}</div>
                <p className="character-description">{c.description}</p>
                <button className="button button-call" disabled={!c.online} onClick={() => { setSelected(c); startCall(); }}><Video size={17}/> {c.online ? "Start video call" : "Coming soon"}</button>
              </div>
            </article>)}
          </div>
          {!visibleCharacters.length && <div className="empty-state">No characters match that search. Try another name or vibe.</div>}
        </section>

        <section className="how-section section" id="how">
          <div className="section-heading centered"><div className="eyebrow">SIMPLE BY DESIGN</div><h2>Your next chat is <span>three steps away.</span></h2><p>A friendly experience, from first click to goodbye.</p></div>
          <div className="steps-grid"><div className="step"><span>01</span><div className="step-icon pink-bg"><UserRound size={23}/></div><h3>Choose a character</h3><p>Explore fictional AI personalities and pick someone whose vibe fits yours.</p></div><div className="step"><span>02</span><div className="step-icon purple-bg"><Video size={23}/></div><h3>Start a call</h3><p>Open the call experience. Live avatar video becomes available when a provider is connected.</p></div><div className="step"><span>03</span><div className="step-icon orange-bg"><MessageCircle size={23}/></div><h3>Talk about anything</h3><p>Send a message, explore a topic, and enjoy a conversation with your AI character.</p></div></div>
        </section>

        <section className="premium-banner section" id="plans"><div className="premium-spark">✦</div><div><div className="eyebrow">MORE ROOM TO CONNECT</div><h2>Make every conversation <span>count.</span></h2><p>Premium plans can unlock longer sessions, more characters, and advanced avatar experiences.</p></div><button className="button button-dark" onClick={() => setNotice("Premium checkout is not connected yet. Add a payment provider before accepting payments.")}><Crown size={17}/> Explore premium</button></section>
      </main>

      <footer><a className="brand" href="#"><span className="brand-mark"><Video size={18}/></span><span>CallVibe <b>AI</b></span></a><p>Made for conversations with fictional AI characters.</p><div className="footer-links"><a href="#how">How it works</a><a href="#plans">Plans</a><button onClick={() => setNotice("Add your privacy policy and terms before public launch.")}>Privacy & terms</button></div><small>© {new Date().getFullYear()} CallVibe AI. AI characters are fictional.</small></footer>

      {notice && <div className="toast" role="status"><span>{notice}</span><button aria-label="Dismiss notice" onClick={() => setNotice("")}><X size={17}/></button></div>}

      {callOpen && <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="AI video call">
        <div className="call-modal">
          <div className="call-header"><div><span className="live-dot"></span><b>{selected.name}</b><small>{callMode === "live" ? "Avatar session" : "AI demo call"} · {formatTime(elapsed)}</small></div><button className="icon-button" aria-label="Close call" onClick={closeCall}><X size={19}/></button></div>
          <div className={`call-stage ${selected.gradient}`}>
            <div className="call-orbit orbit-a"></div><div className="call-orbit orbit-b"></div>
            <div className="call-avatar">{selected.emoji}</div>
            <div className="call-name"><b>{selected.name}</b><small>AI-generated fictional character</small></div>
            <div className="call-stage-note"><Sparkles size={15}/> {callMode === "live" ? "Avatar service connected" : "Preview mode · Connect avatar API for lifelike video"}</div>
            {cameraOn && <div className="self-preview"><Camera size={14}/><span>You</span></div>}
          </div>
          <div className="call-controls"><button className={`round-control ${!micOn ? "muted" : ""}`} onClick={() => setMicOn(v => !v)} aria-label={micOn ? "Mute microphone" : "Unmute microphone"}>{micOn ? <Mic/> : <MicOff/>}</button><button className="round-control" onClick={() => setCameraOn(v => !v)} aria-label="Toggle camera"><Camera/></button><button className="round-control chat-control" onClick={() => setChatOpen(v => !v)} aria-label="Toggle chat"><MessageCircle/></button><button className="round-control end-control" onClick={closeCall} aria-label="End call"><PhoneOff/></button></div>
          {chatOpen && <div className="call-chat"><div className="chat-title"><b><MessageCircle size={16}/> Conversation</b><span>Demo mode</span></div><div className="message-list">{messages.map((m, i) => <div className={`message ${m.from}`} key={i}><span>{m.from === "ai" ? selected.name : "You"}</span><p>{m.text}</p></div>)}</div><form onSubmit={sendMessage} className="chat-compose"><input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Write a message…" aria-label="Message"/><button type="submit" aria-label="Send message"><Send size={17}/></button></form><small className="demo-disclaimer">This is a demo. Real AI replies and live avatar video need provider credentials.</small></div>}
        </div>
      </div>}

      {authOpen && <div className="modal-backdrop auth-backdrop" role="dialog" aria-modal="true" aria-label="Account">
        <form className="auth-modal" onSubmit={signIn}><button type="button" className="close-auth" onClick={() => setAuthOpen(false)} aria-label="Close"><X size={18}/></button><div className="brand-mark auth-mark"><Video size={22}/></div><h2>{authMode === "signup" ? "Create your account" : "Welcome back"}</h2><p>{supabase ? "Your account keeps your preferences in sync." : "Account access is a preview until Supabase is configured."}</p><label>Email address<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input required minLength={6} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="button button-primary auth-submit" disabled={busy}>{busy ? "Please wait…" : authMode === "signup" ? "Create account" : "Sign in"} <LogIn size={16}/></button><button type="button" className="switch-auth" onClick={() => setAuthMode(m => m === "signup" ? "signin" : "signup")}>{authMode === "signup" ? "Already have an account? Sign in" : "New to CallVibe? Create an account"}</button><small>Never share your password with anyone. Add a privacy policy before public launch.</small></form>
      </div>}
    </div>
  );
}
