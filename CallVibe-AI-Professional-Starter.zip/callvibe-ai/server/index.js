import "dotenv/config";
import express from "express";
import cors from "cors";

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || true }));
app.use(express.json({ limit: "1mb" }));

const characters = {
  maya: "Maya, a warm-hearted fictional AI friend",
  leo: "Leo, an adventurous fictional AI character",
  aria: "Aria, a creative fictional AI character",
  noah: "Noah, a thoughtful fictional AI character"
};

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "CallVibe AI", mode: "starter" }));

app.post("/api/chat", async (req, res) => {
  const { characterId, message, history = [] } = req.body || {};
  if (!characters[characterId]) return res.status(400).json({ error: "Unknown character." });
  if (typeof message !== "string" || !message.trim() || message.length > 4000) {
    return res.status(400).json({ error: "Enter a message of up to 4000 characters." });
  }
  if (!process.env.AI_API_KEY) {
    return res.status(503).json({ error: "AI provider is not configured. Add AI_API_KEY on the server." });
  }

  const apiUrl = (process.env.AI_API_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const recent = Array.isArray(history) ? history.slice(-8).map(m => ({
    role: m.from === "you" ? "user" : "assistant",
    content: String(m.text || "").slice(0, 2000)
  })) : [];

  try {
    const response = await fetch(`${apiUrl}/chat/completions`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.AI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: `You are ${characters[characterId]}. You are an AI, not a human. Be warm, safe, honest, and conversational. Never claim to be a real person or to be on a real video call. Keep replies concise.` },
          ...recent,
          { role: "user", content: message.trim() }
        ],
        temperature: 0.8,
        max_tokens: 250
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data?.error?.message || "AI provider request failed." });
    const reply = data?.choices?.[0]?.message?.content?.trim();
    if (!reply) return res.status(502).json({ error: "AI provider returned an empty reply." });
    return res.json({ reply });
  } catch (error) {
    console.error("AI request failed:", error.message);
    return res.status(502).json({ error: "Could not reach the AI provider." });
  }
});

app.post("/api/avatar/session", async (req, res) => {
  const { characterId } = req.body || {};
  if (!characters[characterId]) return res.status(400).json({ error: "Unknown character." });
  if (!process.env.AVATAR_API_KEY || !process.env.AVATAR_API_URL) {
    return res.status(503).json({ error: "Avatar provider is not configured." });
  }
  // Provider APIs differ. Implement the exact request for the avatar vendor you choose.
  // Keep vendor keys server-side and return only a short-lived session token or approved embed URL.
  return res.status(501).json({
    error: "Avatar provider adapter is not implemented yet.",
    message: "Choose a real-time avatar vendor, then implement its documented session endpoint in this route."
  });
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`CallVibe AI API listening on http://localhost:${port}`));
