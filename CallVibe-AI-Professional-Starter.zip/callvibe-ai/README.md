# CallVibe AI — Professional starter

A colorful, mobile-friendly React/Vite frontend and Express API starter for an AI character video-call platform.

## Included now
- Responsive CallVibe AI landing page and character cards
- Demo call screen, call timer, controls, chat panel, and clearly labeled demo replies
- Supabase email/password authentication wiring (needs project credentials)
- Server-side AI chat endpoint wiring (needs an AI API key)
- Avatar-session endpoint placeholder for a selected real-time avatar provider
- Premium-plan presentation placeholder
- Environment variable template and API health endpoint

## Important: what is and isn't live
This project is a **starter**, not a fully deployed commercial service. The call interface is a visual demo until you connect a real-time avatar provider. The `/api/avatar/session` route deliberately returns `501` until you implement the provider's official API. Do not advertise live photorealistic video calls until tested with the chosen provider.

The AI chat endpoint supports an OpenAI-compatible Chat Completions API. Add your provider's server-side key to `.env`. Demo replies are used by the browser if the API isn't available.

Payments are not connected. Before charging users, integrate a payment provider such as Stripe or a supported local provider, verify payments server-side, and add terms, privacy, refund, and cancellation policies.

## Run locally
Requires Node.js 20+.

1. Extract this ZIP.
2. Copy `.env.example` to `.env`.
3. Install packages:
   ```bash
   npm install
   ```
4. Start the API server in one terminal:
   ```bash
   npm start
   ```
5. Start the frontend in another terminal:
   ```bash
   npm run dev
   ```
6. Open the local Vite URL printed in the terminal (normally `http://localhost:5173`).

The frontend dev server does not automatically proxy `/api` to port 8787. For local API testing, either add a Vite proxy in `vite.config.js` or serve the frontend and API behind the same origin. A proxy can be added with:
```js
server: {
  port: 5173,
  proxy: { "/api": "http://localhost:8787" }
}
```

## Supabase setup
1. Create a Supabase project.
2. In Authentication, enable Email sign-in and set your site URL / redirect URLs.
3. Copy the project URL and anon/public key into `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Copy the URL and service-role key into server-side variables only if server-side database operations are later implemented.
5. Never expose a service-role key in frontend code or commit a populated `.env` file.

Authentication UI is wired for email/password sign-in and registration. Persistent call history and user profile tables are not implemented in this starter.

## AI setup
Set server-side `AI_API_KEY`, and optionally `AI_API_URL` and `AI_MODEL`, in `.env`. The API route uses an OpenAI-compatible `/chat/completions` endpoint. Do not put secret keys in variables prefixed with `VITE_`.

## Real-time avatar setup
Choose a provider that explicitly supports real-time interactive avatars and commercial use. Then:
1. Review pricing, data processing, content rules, and terms.
2. Implement the provider's documented server-side session-creation API in `server/index.js`.
3. Return a short-lived session token or approved embed URL to the frontend.
4. Update the call stage to embed the provider's official SDK/player.
5. Never place provider secrets in frontend code.
6. Use only fictional or properly authorized likenesses, disclose AI-generated content, and obtain user consent before accessing a microphone or camera.

The included camera/mic buttons are UI controls only; they do not access device hardware in this starter.

## Deployment
- Deploy the frontend to Vercel or another static hosting provider.
- Deploy `server/` as a Node service, or adapt the API routes to your host's serverless function format.
- Set environment variables in the hosting dashboard.
- Configure the frontend API base URL or use same-origin routing.
- Configure Supabase authentication redirect URLs to match your production domain.
- Test account creation, AI errors, mobile layout, and avatar sessions before launch.

## Suggested next development steps
1. Select an avatar vendor and implement its session adapter.
2. Select and configure your AI provider.
3. Add database tables and Row Level Security policies for profiles and call history.
4. Add real speech input/output and explicit browser microphone permissions.
5. Integrate payment checkout, webhook verification, subscriptions, and usage limits.
6. Add privacy policy, terms, age rules, reporting, and safety controls.
